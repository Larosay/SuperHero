<?php

// Note, this will be updated automatically during grunt release task
$ET_CORE_VERSION = '4.13.0';
